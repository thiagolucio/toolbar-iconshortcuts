# Tool Bar IconShortCurts package
A more complete option of shortcut icons to the toolbar of the ATOM Editor.

It must have installed a toolbar extension of ATOM before...[tool-bar](https://atom.io/packages/tool-bar) package.

![Tool bar Icon Shortcuts](http://www.thiagolucio.com.br/images/toolbar-iconshortcuts.jpg)

# Buttons

* New File
* Open...
*Open Project...
* Save
* Find in Buffer
* Replace in Buffer
* Toggle Command Palette
* Settings View
* Reload Window
* Toggle Developer Tools

